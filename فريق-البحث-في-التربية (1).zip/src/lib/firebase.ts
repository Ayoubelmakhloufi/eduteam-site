import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAaLuRq4ASANaNEThK5xxX0i8ubc-sK9V0",
  authDomain: "eduteam-f88df.firebaseapp.com",
  projectId: "eduteam-f88df",
  storageBucket: "eduteam-f88df.firebasestorage.app",
  messagingSenderId: "554685357889",
  appId: "1:554685357889:web:aa208283184a4302604bc0",
  measurementId: "G-BR2WPPPB4Q"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
