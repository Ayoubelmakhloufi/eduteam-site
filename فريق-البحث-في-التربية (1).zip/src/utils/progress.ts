export interface CourseProgress {
  completedInterventions: number[]; // Array of completed intervention IDs
  currentIntervention: number; // ID of the current unlocked intervention
}

const STORAGE_KEY = 'course_progress_school_society';

export const getProgress = (): CourseProgress => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (stored) {
    return JSON.parse(stored);
  }
  return {
    completedInterventions: [],
    currentIntervention: 1 // Start at 1
  };
};

export const saveProgress = (progress: CourseProgress) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
};

export const completeIntervention = (interventionId: number) => {
  const progress = getProgress();
  if (!progress.completedInterventions.includes(interventionId)) {
    progress.completedInterventions.push(interventionId);
    // Unlock next intervention if it's the current one
    if (progress.currentIntervention === interventionId) {
      progress.currentIntervention = interventionId + 1;
    }
    saveProgress(progress);
  }
};

export const isInterventionUnlocked = (interventionId: number): boolean => {
  const progress = getProgress();
  return interventionId <= progress.currentIntervention;
};

export const isInterventionCompleted = (interventionId: number): boolean => {
  const progress = getProgress();
  return progress.completedInterventions.includes(interventionId);
};
