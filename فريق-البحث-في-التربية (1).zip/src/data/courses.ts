import { Course } from '../types';
import { intervention1 } from './intervention1';
import { intervention2 } from './intervention2';
import { intervention3 } from './intervention3';
import { intervention4 } from './intervention4';
import { intervention5 } from './intervention5';
import { intervention6 } from './intervention6';
import { intervention7 } from './intervention7';
import { intervention8 } from './intervention8';

export const courses: Course[] = [
  {
    id: "school-society",
    title: "المدرسة والمجتمع - رهانات وتحديات",
    description: "دورة تكوينية شاملة تتناول قضايا المدرسة والمجتمع من زوايا متعددة: نفسية، اجتماعية، معرفية، قيمية، وبيئية.",
    interventions: [
      intervention1,
      intervention2,
      intervention3,
      intervention4,
      intervention5,
      intervention6,
      intervention7,
      intervention8
    ]
  }
];
