import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-gray-500 text-center md:text-right">
            <p>© {new Date().getFullYear()} فريق البحث في التربية وديداكتيك التربية الإسلامية. جميع الحقوق محفوظة.</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <span>صمم بحب</span>
            <Heart size={14} className="text-red-500 fill-red-500" />
            <span>لخدمة التربية والتعليم</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
