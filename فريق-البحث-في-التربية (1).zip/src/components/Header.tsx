import { Link } from 'react-router-dom';
import { BookOpen, GraduationCap, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export default function Header() {
  const { user, signInWithGoogle, logout } = useAuth();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <div className="bg-emerald-600 p-2 rounded-lg text-white">
                <GraduationCap size={24} />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg text-gray-900 leading-tight">فريق البحث في التربية</span>
                <span className="text-xs text-emerald-600 font-medium">وديداكتيك التربية الإسلامية</span>
              </div>
            </Link>
          </div>
          <nav className="flex items-center gap-4">
            <Link to="/" className="text-gray-600 hover:text-emerald-600 font-medium transition-colors hidden md:block">
              الرئيسية
            </Link>
            <Link to="/courses" className="text-gray-600 hover:text-emerald-600 font-medium transition-colors flex items-center gap-1">
              <BookOpen size={18} />
              <span className="hidden md:inline">الدورات التكوينية</span>
            </Link>
            
            {user ? (
              <div className="flex items-center gap-3 mr-4 border-r border-gray-200 pr-4">
                <div className="flex items-center gap-2">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || 'User'} className="w-8 h-8 rounded-full border border-gray-200" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold">
                      {user.displayName ? user.displayName[0].toUpperCase() : 'U'}
                    </div>
                  )}
                  <span className="text-sm font-medium text-gray-700 hidden sm:block">{user.displayName}</span>
                </div>
                <button 
                  onClick={logout}
                  className="text-gray-500 hover:text-red-500 transition-colors p-1 rounded-full hover:bg-gray-100"
                  title="تسجيل الخروج"
                >
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 font-medium py-2 px-4 rounded-lg transition-colors flex items-center gap-2 text-sm shadow-sm"
              >
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-4 h-4" />
                <span>تسجيل الدخول</span>
              </button>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
