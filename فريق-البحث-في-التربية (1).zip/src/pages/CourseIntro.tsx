import { Link, useParams } from 'react-router-dom';
import { courses } from '../data/courses';
import { useProgress } from '../hooks/useProgress';
import { CheckCircle, Lock, PlayCircle, Clock, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

export default function CourseIntro() {
  const { courseId } = useParams<{ courseId: string }>();
  const course = courses.find(c => c.id === courseId);
  const { progress, loading } = useProgress(courseId);

  if (!course) {
    return <div className="text-center py-20 text-gray-500">الدورة غير موجودة</div>;
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const completedCount = progress.completedInterventions.length;
  const totalCount = course.interventions.length;
  const progressPercentage = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="bg-gray-50 min-h-screen py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Course Header */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-12">
          <div className="bg-emerald-600 p-8 md:p-12 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-800 to-emerald-500 opacity-90"></div>
            <div className="relative z-10">
              <span className="bg-emerald-800/50 text-emerald-100 px-3 py-1 rounded-full text-sm font-medium mb-4 inline-block">دورة تكوينية</span>
              <h1 className="text-3xl md:text-5xl font-bold mb-4">{course.title}</h1>
              <p className="text-emerald-100 text-lg max-w-3xl leading-relaxed opacity-90">{course.description}</p>
              
              <div className="flex flex-wrap gap-6 mt-8 text-sm font-medium">
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm">
                  <BookOpen size={18} />
                  <span>{totalCount} مداخلات</span>
                </div>
                <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm">
                  <Clock size={18} />
                  <span>تعلم ذاتي</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="p-8 border-b border-gray-100">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-700 font-bold">تقدمك في الدورة</span>
              <span className="text-emerald-600 font-bold">{progressPercentage}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progressPercentage}%` }}
                className="bg-emerald-500 h-3 rounded-full"
              ></motion.div>
            </div>
            {progressPercentage === 100 && (
              <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center justify-between">
                <div className="flex items-center gap-3 text-green-800">
                  <CheckCircle className="text-green-600" />
                  <span className="font-bold">مبارك! لقد أتممت الدورة بنجاح.</span>
                </div>
                <Link 
                  to="/certificate" 
                  className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors font-bold shadow-sm"
                >
                  استلام الشهادة
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Interventions List */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 border-r-4 border-emerald-500 pr-4">محتوى الدورة</h2>
          
          {course.interventions.map((intervention, index) => {
            const isUnlocked = intervention.id <= progress.currentIntervention;
            const isCompleted = progress.completedInterventions.includes(intervention.id);
            
            return (
              <motion.div 
                key={intervention.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-xl shadow-sm border transition-all duration-300 ${
                  isUnlocked 
                    ? 'border-gray-200 hover:shadow-md hover:border-emerald-200' 
                    : 'border-gray-100 opacity-60 bg-gray-50'
                }`}
              >
                <div className="flex items-center p-6">
                  <div className={`flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center mr-4 ml-6 ${
                    isCompleted ? 'bg-green-100 text-green-600' : 
                    isUnlocked ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-200 text-gray-400'
                  }`}>
                    {isCompleted ? <CheckCircle size={24} /> : isUnlocked ? <PlayCircle size={24} /> : <Lock size={24} />}
                  </div>
                  
                  <div className="flex-grow">
                    <div className="flex items-center gap-3 mb-1">
                      <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">المداخلة {index + 1}</span>
                      {isCompleted && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">مكتمل</span>}
                    </div>
                    <h3 className={`text-lg font-bold ${isUnlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                      {intervention.title}
                    </h3>
                  </div>
                  
                  <div className="flex-shrink-0 mr-4">
                    {isUnlocked ? (
                      <Link 
                        to={`/courses/${courseId}/intervention/${intervention.id}`}
                        className={`inline-flex items-center justify-center px-6 py-2 border border-transparent text-sm font-medium rounded-lg shadow-sm text-white focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                          isCompleted 
                            ? 'bg-emerald-600 hover:bg-emerald-700 focus:ring-emerald-500' 
                            : 'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500'
                        }`}
                      >
                        {isCompleted ? 'مراجعة' : 'ابدأ الدرس'}
                      </Link>
                    ) : (
                      <button disabled className="px-6 py-2 border border-gray-200 text-sm font-medium rounded-lg text-gray-400 bg-gray-50 cursor-not-allowed">
                        مغلق
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
