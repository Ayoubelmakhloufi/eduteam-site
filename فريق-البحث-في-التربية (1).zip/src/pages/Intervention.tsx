import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { courses } from '../data/courses';
import { useProgress } from '../hooks/useProgress';
import { CheckCircle, XCircle, ArrowRight, ArrowLeft, PlayCircle, FileText, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

export default function Intervention() {
  const { courseId, interventionId } = useParams<{ courseId: string; interventionId: string }>();
  const navigate = useNavigate();
  
  const course = courses.find(c => c.id === courseId);
  const intervention = course?.interventions.find(i => i.id === Number(interventionId));
  const { progress, loading, completeIntervention } = useProgress(courseId);
  
  const [activeTab, setActiveTab] = useState<'video' | 'text' | 'quiz'>('video');
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  useEffect(() => {
    setActiveTab('video');
    setQuizStarted(false);
    setCurrentQuestion(0);
    setScore(0);
    setShowResult(false);
    setSelectedOption(null);
    setIsAnswered(false);
  }, [interventionId]);

  useEffect(() => {
    if (!intervention) {
      navigate('/courses');
      return;
    }
    // Check if unlocked
    if (!loading && intervention.id > progress.currentIntervention) {
      navigate(`/courses/${courseId}`);
    }
  }, [intervention, interventionId, courseId, navigate, progress, loading]);

  if (!intervention) return null;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const handleAnswer = (optionIndex: number) => {
    if (isAnswered) return;
    setSelectedOption(optionIndex);
    setIsAnswered(true);
    
    if (optionIndex === intervention.quiz[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < intervention.quiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResult(true);
      const passThreshold = Math.ceil(intervention.quiz.length / 2);
      if (score >= passThreshold) {
        completeIntervention(intervention.id);
      }
    }
  };

  const resetQuiz = () => {
    setScore(0);
    setCurrentQuestion(0);
    setShowResult(false);
    setSelectedOption(null);
    setIsAnswered(false);
    setQuizStarted(false);
  };

  const passThreshold = Math.ceil(intervention.quiz.length / 2);
  const passed = score >= passThreshold;
  const isLastIntervention = intervention.id === course?.interventions.length;

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <button 
            onClick={() => navigate(`/courses/${courseId}`)}
            className="flex items-center text-gray-600 hover:text-emerald-600 transition-colors"
          >
            <ArrowRight size={20} className="ml-2" />
            العودة للدورة
          </button>
          <h1 className="text-xl font-bold text-gray-900 truncate max-w-md">{intervention.title}</h1>
        </div>

        {/* Main Content Card */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden min-h-[600px] flex flex-col">
          
          {/* Tabs */}
          <div className="flex border-b border-gray-100">
            <button
              onClick={() => setActiveTab('video')}
              className={`flex-1 py-4 text-center font-bold text-sm transition-colors flex items-center justify-center gap-2 ${
                activeTab === 'video' ? 'bg-emerald-50 text-emerald-600 border-b-2 border-emerald-600' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <PlayCircle size={18} />
              الفيديو
            </button>
            <button
              onClick={() => setActiveTab('text')}
              className={`flex-1 py-4 text-center font-bold text-sm transition-colors flex items-center justify-center gap-2 ${
                activeTab === 'text' ? 'bg-emerald-50 text-emerald-600 border-b-2 border-emerald-600' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <FileText size={18} />
              النص المقروء
            </button>
            <button
              onClick={() => setActiveTab('quiz')}
              className={`flex-1 py-4 text-center font-bold text-sm transition-colors flex items-center justify-center gap-2 ${
                activeTab === 'quiz' ? 'bg-emerald-50 text-emerald-600 border-b-2 border-emerald-600' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <HelpCircle size={18} />
              الاختبار
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-grow p-6 md:p-8 bg-gray-50/50">
            
            {/* Video Tab */}
            {activeTab === 'video' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center"
              >
                <div className="w-full aspect-video rounded-xl overflow-hidden shadow-lg bg-black">
                  <iframe
                    width="100%"
                    height="100%"
                    src={`https://www.youtube.com/embed/${intervention.videoId}`}
                    title={intervention.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
                <p className="mt-6 text-gray-600 text-center max-w-2xl">
                  شاهد الفيديو بعناية، ثم انتقل لقراءة النص أو إجراء الاختبار لتقييم فهمك.
                </p>
                <button 
                  onClick={() => setActiveTab('text')}
                  className="mt-8 bg-emerald-600 text-white px-8 py-3 rounded-full hover:bg-emerald-700 transition-colors font-bold shadow-lg flex items-center gap-2"
                >
                  قراءة النص
                  <ArrowLeft size={18} />
                </button>
              </motion.div>
            )}

            {/* Text Tab */}
            {activeTab === 'text' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="prose prose-lg max-w-none text-gray-800 leading-relaxed whitespace-pre-wrap font-sans"
              >
                <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
                  {intervention.content}
                </div>
                <div className="mt-8 text-center">
                  <button 
                    onClick={() => setActiveTab('quiz')}
                    className="bg-emerald-600 text-white px-8 py-3 rounded-full hover:bg-emerald-700 transition-colors font-bold shadow-lg flex items-center gap-2 mx-auto"
                  >
                    بدء الاختبار
                    <ArrowLeft size={18} />
                  </button>
                </div>
              </motion.div>
            )}

            {/* Quiz Tab */}
            {activeTab === 'quiz' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-2xl mx-auto"
              >
                {!quizStarted ? (
                  <div className="text-center py-12">
                    <div className="bg-emerald-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                      <HelpCircle size={48} className="text-emerald-600" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">اختبار المداخلة</h2>
                    <p className="text-gray-600 mb-8">
                      يتكون هذا الاختبار من {intervention.quiz.length} أسئلة.
                      <br />
                      يجب عليك الإجابة بشكل صحيح على {passThreshold} أسئلة على الأقل للمرور للمداخلة التالية.
                    </p>
                    <button
                      onClick={() => setQuizStarted(true)}
                      className="bg-emerald-600 text-white px-8 py-3 rounded-full hover:bg-emerald-700 transition-colors font-bold shadow-lg"
                    >
                      ابدأ الاختبار الآن
                    </button>
                  </div>
                ) : showResult ? (
                  <div className="text-center py-12 bg-white rounded-xl shadow-sm border border-gray-100 p-8">
                    <div className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 ${passed ? 'bg-green-100' : 'bg-red-100'}`}>
                      {passed ? <CheckCircle size={48} className="text-green-600" /> : <XCircle size={48} className="text-red-600" />}
                    </div>
                    <h2 className="text-3xl font-bold text-gray-900 mb-2">
                      {passed ? 'أحسنت!' : 'حاول مرة أخرى'}
                    </h2>
                    <p className="text-xl text-gray-600 mb-8">
                      لقد أجبت بشكل صحيح على <span className="font-bold text-gray-900">{score}</span> من <span className="font-bold text-gray-900">{intervention.quiz.length}</span> أسئلة.
                    </p>
                    
                    <div className="flex flex-col gap-4 max-w-xs mx-auto">
                      {passed ? (
                        isLastIntervention ? (
                          <button
                            onClick={() => navigate('/certificate')}
                            className="bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-colors font-bold shadow-md"
                          >
                            استلام الشهادة
                          </button>
                        ) : (
                          <button
                            onClick={() => {
                                const nextId = intervention.id + 1;
                                navigate(`/courses/${courseId}/intervention/${nextId}`);
                                // Reset state for next intervention
                                setActiveTab('video');
                                resetQuiz();
                            }}
                            className="bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-colors font-bold shadow-md flex items-center justify-center gap-2"
                          >
                            المداخلة التالية
                            <ArrowLeft size={18} />
                          </button>
                        )
                      ) : (
                        <button
                          onClick={resetQuiz}
                          className="bg-gray-800 text-white px-6 py-3 rounded-lg hover:bg-gray-900 transition-colors font-bold shadow-md"
                        >
                          إعادة الاختبار
                        </button>
                      )}
                      <button
                        onClick={() => navigate(`/courses/${courseId}`)}
                        className="text-gray-500 hover:text-gray-700 font-medium mt-2"
                      >
                        العودة لقائمة الدروس
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                    <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                      <span className="font-bold text-gray-500">سؤال {currentQuestion + 1} من {intervention.quiz.length}</span>
                      <span className="text-sm bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full font-medium">
                        النتيجة: {score}
                      </span>
                    </div>
                    <div className="p-8">
                      <h3 className="text-xl font-bold text-gray-900 mb-8 leading-relaxed">
                        {intervention.quiz[currentQuestion].text}
                      </h3>
                      <div className="space-y-4">
                        {intervention.quiz[currentQuestion].options.map((option, index) => (
                          <button
                            key={index}
                            onClick={() => handleAnswer(index)}
                            disabled={isAnswered}
                            className={`w-full text-right p-4 rounded-xl border-2 transition-all ${
                              selectedOption === index 
                                ? isAnswered 
                                  ? index === intervention.quiz[currentQuestion].correctAnswer 
                                    ? 'border-green-500 bg-green-50 text-green-800' 
                                    : 'border-red-500 bg-red-50 text-red-800'
                                  : 'border-emerald-500 bg-emerald-50'
                                : isAnswered && index === intervention.quiz[currentQuestion].correctAnswer
                                  ? 'border-green-500 bg-green-50 text-green-800'
                                  : 'border-gray-200 hover:border-emerald-200 hover:bg-gray-50'
                            }`}
                          >
                            <div className="flex items-center">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ml-4 font-bold ${
                                selectedOption === index
                                  ? isAnswered
                                    ? index === intervention.quiz[currentQuestion].correctAnswer
                                      ? 'border-green-500 text-green-600 bg-white'
                                      : 'border-red-500 text-red-600 bg-white'
                                    : 'border-emerald-500 text-emerald-600 bg-white'
                                  : isAnswered && index === intervention.quiz[currentQuestion].correctAnswer
                                    ? 'border-green-500 text-green-600 bg-white'
                                    : 'border-gray-300 text-gray-400'
                              }`}>
                                {['أ', 'ب', 'ج', 'د'][index]}
                              </div>
                              <span className="font-medium">{option}</span>
                              {isAnswered && index === intervention.quiz[currentQuestion].correctAnswer && (
                                <CheckCircle className="mr-auto text-green-500" size={20} />
                              )}
                              {isAnswered && selectedOption === index && index !== intervention.quiz[currentQuestion].correctAnswer && (
                                <XCircle className="mr-auto text-red-500" size={20} />
                              )}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                    {isAnswered && (
                      <div className="bg-gray-50 px-6 py-4 border-t border-gray-100 flex justify-end">
                        <button
                          onClick={handleNextQuestion}
                          className="bg-emerald-600 text-white px-8 py-3 rounded-lg hover:bg-emerald-700 transition-colors font-bold shadow-md flex items-center gap-2"
                        >
                          {currentQuestion < intervention.quiz.length - 1 ? 'السؤال التالي' : 'إنهاء الاختبار'}
                          <ArrowLeft size={18} />
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
