import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, GraduationCap, Users } from 'lucide-react';
import { motion } from 'motion/react';

export default function Home() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-emerald-600 text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-700 to-emerald-500 opacity-90"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32 flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              فريق البحث في التربية
              <br />
              <span className="text-emerald-200">وديداكتيك التربية الإسلامية</span>
            </h1>
            <p className="text-xl md:text-2xl text-emerald-100 max-w-3xl mb-10">
              منصة تعليمية رائدة تهدف إلى تطوير الكفايات التربوية وتعزيز القيم في الوسط المدرسي من خلال دورات تكوينية متخصصة.
            </p>
            <Link
              to="/courses"
              className="bg-white text-emerald-700 hover:bg-emerald-50 font-bold py-4 px-8 rounded-full shadow-lg transition-all transform hover:scale-105 inline-flex items-center gap-2"
            >
              <BookOpen size={24} />
              ابدأ التعلم الآن
            </Link>
          </motion.div>
        </div>
        
        {/* Decorative pattern */}
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-white" style={{ clipPath: 'polygon(0 100%, 100% 100%, 100% 0, 0 100%)' }}></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">لماذا تختار منصتنا؟</h2>
            <div className="w-24 h-1 bg-emerald-500 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<GraduationCap size={40} className="text-emerald-600" />}
              title="محتوى أكاديمي رصين"
              description="دورات معدة من قبل نخبة من الأساتذة والباحثين المتخصصين في مجال التربية والديداكتيك."
            />
            <FeatureCard 
              icon={<Users size={40} className="text-emerald-600" />}
              title="تفاعلية ومشاركة"
              description="نظام تعليمي تفاعلي يضمن استيعاب المحتوى من خلال اختبارات تقويمية مستمرة."
            />
            <FeatureCard 
              icon={<BookOpen size={40} className="text-emerald-600" />}
              title="شهادات معتمدة"
              description="احصل على شهادة إتمام الدورة بعد اجتياز جميع الاختبارات بنجاح."
            />
          </div>
        </div>
      </section>

      {/* Latest Course Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
                <img 
                  src="https://images.unsplash.com/photo-1524178232363-1fb2b075b655?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                  alt="Education" 
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-emerald-900/20"></div>
              </div>
            </div>
            <div className="md:w-1/2 text-right">
              <span className="text-emerald-600 font-bold tracking-wider uppercase text-sm mb-2 block">دورة مميزة</span>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">المدرسة والمجتمع - رهانات وتحديات</h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                انضم إلينا في رحلة معرفية شيقة لاستكشاف العلاقة الجدلية بين المدرسة والمجتمع، والتحديات التي تواجه المنظومة التربوية في ظل التحولات المعاصرة.
              </p>
              <div className="flex gap-4">
                <Link 
                  to="/courses/school-society"
                  className="bg-emerald-600 text-white hover:bg-emerald-700 font-bold py-3 px-8 rounded-lg shadow-md transition-colors"
                >
                  تفاصيل الدورة
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <motion.div 
      whileHover={{ y: -10 }}
      className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 text-center hover:border-emerald-100 transition-colors"
    >
      <div className="bg-emerald-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-gray-900 mb-4">{title}</h3>
      <p className="text-gray-600 leading-relaxed">
        {description}
      </p>
    </motion.div>
  );
}
