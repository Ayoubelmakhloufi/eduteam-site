import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProgress } from '../hooks/useProgress';
import { courses } from '../data/courses';
import { Award, CheckCircle, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';

export default function Certificate() {
  const navigate = useNavigate();
  const course = courses[0]; // Assuming single course for now
  const { progress, loading } = useProgress(course.id);

  useEffect(() => {
    if (loading) return;
    // Check if all interventions are completed
    const allCompleted = course.interventions.every(i => progress.completedInterventions.includes(i.id));
    if (!allCompleted) {
      navigate('/courses/school-society');
    }
  }, [course, progress, navigate, loading]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="max-w-3xl w-full bg-white rounded-2xl shadow-2xl overflow-hidden text-center relative"
      >
        <div className="bg-emerald-600 h-32 relative overflow-hidden flex items-center justify-center">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-800 to-emerald-500 opacity-90"></div>
          <Award size={64} className="text-white relative z-10" />
        </div>
        
        <div className="p-10 md:p-16">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">تهانينا الحارة!</h1>
          <p className="text-xl text-gray-600 mb-8">
            لقد أتممت بنجاح الدورة التكوينية:
            <br />
            <span className="font-bold text-emerald-600 mt-2 block text-2xl">{course.title}</span>
          </p>
          
          <div className="bg-green-50 border border-green-100 rounded-xl p-6 mb-10 max-w-lg mx-auto">
            <div className="flex items-center justify-center gap-2 text-green-800 mb-2">
              <CheckCircle size={20} />
              <span className="font-bold">تم اجتياز جميع الاختبارات</span>
            </div>
            <p className="text-green-700 text-sm">
              أنت الآن مؤهل للحصول على شهادة إتمام الدورة.
            </p>
          </div>

          <p className="text-gray-600 mb-8 max-w-lg mx-auto">
            يرجى ملء النموذج التالي بمعلوماتك الشخصية ليتم إرسال الشهادة إليك عبر البريد الإلكتروني.
          </p>

          <a 
            href="https://forms.gle/id52Rp6haYzQUJUg9" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 bg-emerald-600 text-white px-8 py-4 rounded-full hover:bg-emerald-700 transition-colors font-bold shadow-lg text-lg transform hover:scale-105 transition-transform"
          >
            ملء نموذج طلب الشهادة
            <ExternalLink size={20} />
          </a>
        </div>
      </motion.div>
    </div>
  );
}
