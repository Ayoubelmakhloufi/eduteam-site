import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { CourseProgress, getProgress as getLocalProgress, saveProgress as saveLocalProgress } from '../utils/progress';

export const useProgress = (courseId: string = 'school-society') => {
  const { user } = useAuth();
  const [progress, setProgress] = useState<CourseProgress>({
    completedInterventions: [],
    currentIntervention: 1
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribe: () => void;

    if (user) {
      setLoading(true);
      const docRef = doc(db, 'users', user.uid, 'progress', courseId);
      
      unsubscribe = onSnapshot(docRef, (docSnap) => {
        if (docSnap.exists()) {
          setProgress(docSnap.data() as CourseProgress);
        } else {
          // Initialize with default if no cloud data exists
          const initialProgress = {
            completedInterventions: [],
            currentIntervention: 1
          };
          setDoc(docRef, initialProgress);
          setProgress(initialProgress);
        }
        setLoading(false);
      });
    } else {
      // Load from local storage
      setProgress(getLocalProgress());
      setLoading(false);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [user, courseId]);

  const completeIntervention = async (interventionId: number) => {
    let newCompleted = [...progress.completedInterventions];
    if (!newCompleted.includes(interventionId)) {
      newCompleted.push(interventionId);
    }
    
    let newCurrent = progress.currentIntervention;
    if (progress.currentIntervention === interventionId) {
      newCurrent = interventionId + 1;
    }

    const newProgress = {
      completedInterventions: newCompleted,
      currentIntervention: newCurrent
    };

    // Optimistic update
    setProgress(newProgress);

    if (user) {
      const docRef = doc(db, 'users', user.uid, 'progress', courseId);
      await setDoc(docRef, newProgress, { merge: true });
    } else {
      saveLocalProgress(newProgress);
    }
  };

  return { progress, loading, completeIntervention };
};
