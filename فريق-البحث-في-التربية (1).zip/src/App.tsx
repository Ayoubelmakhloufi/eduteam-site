/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import CourseIntro from './pages/CourseIntro';
import Intervention from './pages/Intervention';
import Certificate from './pages/Certificate';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="courses" element={<Navigate to="/courses/school-society" replace />} />
            <Route path="courses/:courseId" element={<CourseIntro />} />
            <Route path="courses/:courseId/intervention/:interventionId" element={<Intervention />} />
            <Route path="certificate" element={<Certificate />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
