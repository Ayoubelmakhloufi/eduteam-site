export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Intervention {
  id: number;
  title: string;
  videoId: string;
  content: string;
  quiz: Question[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  interventions: Intervention[];
}
